# Based on the discretization method in the paper "Nonlinear
# household earnings dynamics, self-insurance, and welfare,"
# (Mariacristina De Nardi, Giulio Fella and Gonzalo Paz-Pardo) forthcoming
# in the Journal of the European Economic Association

if (!require(data.table)) install.packages("data.table")
if (!require(statar)) install.packages("statar")

library(data.table)
library(statar)

rm(list=ls())

setwd("C:/Users/jpan/Documents/repos/fgp/")

param <- fread("temp/AddaCooper_parameters_nmar.csv")
bin_size <- param[1, V1]
rho <- param[1, V2]
mu_e1 <- param[1, V3]
mu_e2 <- param[1, V4]
sigma_e1 <- param[1, V5]
sigma_e2 <- param[1, V6]
p1_e <- param[1, V7]

n_person <- 500000
n_age <- 40
e1.mat <- matrix(nrow = n_person, ncol = n_age)
e2.mat <- matrix(nrow = n_person, ncol = n_age)
draw.mat <- matrix(nrow = n_person, ncol = n_age)
y.mat <- matrix(nrow = n_person, ncol = n_age)

set.seed(123)
e1.mat[, 1] <- rnorm(n_person, sd = sigma_e1, mean = mu_e1)
e2.mat[, 1] <- rnorm(n_person, sd = sigma_e2, mean = mu_e2)
draw.mat[, 1] <- rbinom(n_person, size = 1, prob = p1_e)
y.mat[, 1] <- draw.mat[, 1] * e1.mat[, 1] + (1-draw.mat[, 1]) * e2.mat[, 1]
for (t in seq(2,n_age)) {
  e1.mat[, t] <- rnorm(n_person, sd = sigma_e1, mean = mu_e1)
  e2.mat[, t] <- rnorm(n_person, sd = sigma_e2, mean = mu_e2)
  draw.mat[, t] <- rbinom(n_person, size = 1, prob = p1_e)
  y.mat[, t] <- rho * y.mat[, t-1] + draw.mat[, t] * e1.mat[, t] + (1-draw.mat[, t]) * e2.mat[, t]
}

y.dt <- data.table(y.mat)
names(y.dt) <- as.character(seq(1,40))
y.dt[, id := .I]
df <- melt(y.dt, id.vars = "id", variable.name = "age", value.name = "log_y",
           variable.factor = FALSE)
rm(e1.mat, e2.mat, draw.mat, y.mat, y.dt)
df[, age := as.integer(age)]

setkeyv(df, c("age","id"))
df[, bin := xtile(log_y, n = bin_size), by=age]

# --- Now save gridpoints and values ---

setkeyv(df, c("age","bin"))
# Adda-Cooper: construct state vectors using bin-specific means
aa <- df[, mean(log_y), by = list(age,bin)]
# Kennan: construct state vectors using bin-specific medians
#aa <- df[, median(log_y), by = list(age,bin)]


# --- Now compute jumps ---

df[, log_y := NULL]

setkeyv(df, c("id","age"))

df[, nextbin := shift(bin, type="lead")]

# --- Need to compute counts ---
df <- subset(df, age < max(df$age)) # no counts for last age
dat1 <- df[, .N, keyby=c('age','bin','nextbin')]
dat2 <- with(dat1, expand.grid(age=min(df$age):max(df$age), bin=1:max(df$bin), nextbin=1:max(df$bin)))
dat1 <- merge(dat1, dat2, all.y = TRUE)
dat1[is.na(N), N := 0]
dat1[, prop := N/sum(N), by = c("age","bin")]

# --- Export grid and transition matrix ---
grid <- dcast(aa, bin ~ age, value.var = "V1")
fwrite(grid[, -"bin"], "temp/AddaCooper_ygrid.csv", col.names = FALSE)
trans <- dcast(dat1, bin + nextbin ~ age, value.var = "prop")
fwrite(trans[, -c("bin","nextbin")], "temp/AddaCooper_trans.csv", col.names = FALSE)
