if (!require(data.table)) install.packages("data.table")

library(data.table)

setwd("C:/Users/jpan/Documents/repos/fgp/")

computeKellySkewness <- function(x) {
  # x is expected to be a vector
  p10 <- quantile(x, probs = 0.1)
  p50 <- quantile(x, probs = 0.5)
  p90 <- quantile(x, probs = 0.9)
  skewness <- (p90 + p10 - 2*p50)/(p90 - p10)
}

computeCSKurtosis <- function(x) {
  # x is expected to be a vector
  p2.5 <- quantile(x, probs = 0.025)
  p25 <- quantile(x, probs = 0.25)
  p75 <- quantile(x, probs = 0.75)
  p97.5 <- quantile(x, probs = 0.975)
  kurtosis <- (p97.5 - p2.5)/(p75 - p25)
}

panelToResults <- function(filename_suffix, dt) {
  y <- unlist(fread(paste0("output/y_", filename_suffix)))
  c <- unlist(fread(paste0("output/c_", filename_suffix)))
  a <- unlist(fread(paste0("output/a_", filename_suffix)))

  skew_y <- computeKellySkewness(log(y))
  skew_c <- computeKellySkewness(c)
  skew_a <- computeKellySkewness(a)
  kurt_y <- computeCSKurtosis(log(y))
  kurt_c <- computeCSKurtosis(c)
  kurt_a <- computeCSKurtosis(a)

  dt <- rbind(dt, list(as.numeric(rho), sim, method, as.integer(nygrid), skew_y, kurt_y, skew_c, kurt_c, skew_a, kurt_a))
}


dt <- data.table(rho = numeric(), sim = integer(), method = integer(), nygrid = integer(),
                 skew_y = numeric(), kurt_y = numeric(),
                 skew_c = numeric(), kurt_c = numeric(),
                 skew_a = numeric(), kurt_a = numeric())

for (rho in c("0.95","0.98","1.00")) {
  for (sim in 1:2) {
    for (method in 0:3) {

      if (sim==1 & method==0) next

      if (method == 0) {
        
        nygrid <- 10000L
        filename_suffix <- paste0(rho, "_", sim, "_", method, "_", nygrid, ".csv")
        if (file.exists(paste0("output/y_", filename_suffix))) {
          dt <- panelToResults(filename_suffix, dt)
        }
      
      } else {

        for (nygrid in c(" 5","10","25")) {

          filename_suffix <- paste0(rho, "_", sim, "_", method, "_", nygrid, ".csv")
          if (file.exists(paste0("output/y_", filename_suffix))) {
            dt <- panelToResults(filename_suffix, dt)
          }

        }

      }

    }
  }
}
